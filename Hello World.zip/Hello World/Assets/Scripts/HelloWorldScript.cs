﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HelloWorldScript : MonoBehaviour
{
	public GameObject popupPanel;	
	public InputField nameField;
	public Text messageText;

    // Start is called before the first frame update
    void Start()
    {
        hidePopupPanel();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
	
	public void showPopupPanel()
	{
		popupPanel.SetActive(true);
	}
	
	public void hidePopupPanel()
	{
		popupPanel.SetActive(false);
	}
	
	public void sayHello()
	{
		messageText.text = "Hello " + nameField.text + "!";
		showPopupPanel();		
	}
}
